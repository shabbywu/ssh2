# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['ssh2', 'ssh2.cli', 'ssh2.models', 'ssh2.plugins', 'ssh2.utils']

package_data = \
{'': ['*']}

modules = \
['ssh2_wrapper']
install_requires = \
['PyYaml==5.1.2',
 'aenum==2.2.2',
 'click>=7.0',
 'cryptography==2.8',
 'sqlalchemy==1.3.10']

extras_require = \
{'ioa': ['ssh2-ioa']}

entry_points = \
{'console_scripts': ['ssh2 = ssh2.cli.main:cli']}

setup_kwargs = {
    'name': 'ssh2',
    'version': '0.1.0',
    'description': 'A Tool to manage ssh connection',
    'long_description': "# 增强 SSH\nssh连接管理工具\n项目背景: 方便管理 ssh 连接，降低登录服务器的成本\n使用场景:\n-   管理 ssh 账号、密码、秘钥等配置\n-   一键登录服务器\n-   基于 expect 指令进行额外操作(e.g. 通过跳板机登录运维机)\n\n## 使用说明\n### 如何安装该项目\n本项目使用 [poetry](https://python-poetry.org/) 管理依赖和打包, 目前该项目未发布至任何 pypi 仓库, 因此只能从源码安装。\n1. 请根据 [官方文档](https://python-poetry.org/docs/#installation) 安装 poetry\n2. 下载源码\n```bash\n#!/usr/bin/env bash\ngit clone github https://github.com/shabbywu/ssh2.git\n```\n3. 使用 poetry 打包项目\n```bash\n#!/usr/bin/env bash\n# 假设你刚执行完 git clone\ncd ssh2\npoetry build\n```\n4. 安装\np.s. 推荐使用 [pipx](https://pipxproject.github.io/pipx/) 管理基于 pip 安装的命令\n```bash\n#!/usr/bin/env bash\n# 假设你刚执行 poetry build\ncd dist\n## 简单使用\npip install ssh2-0.1.0.tar.gz\n## 使用 pipx\npipx install ssh2-0.1.0.tar.gz\n\n## 加载 ssh2_wrapper.sh 内置的指令\nbash\nsource $(ssh2 get-wrapper-dot-sh)\n\n```\n5. 使用(demo)\n```bash\ncat > demo.yal <<< EOF\n## Create with a nested object\nkind: Session\nspec:\n    tag: str\n    name: str\n    plugins:\n        -   kind:   SSH_LOGIN\n            args:\n    client:\n        spec:\n            user: username_whose_login_to_server\n            name: unique_name_to_mark_this_client\n            auth:\n                spec:\n                    name: unique_name_to_mark_this_auth\n                    type: PASSWORD\n                    content: your_password\n                    expect_for_password: str\n    server:\n        spec:\n            name: unique_name_to_mark_this_server\n            host: host_of_server\n            port: port_of_server\n---\n# Create with multi object\nkind: ClientConfig\nspec:\n  name: unique_name_to_mark_this_client\n  user: username_whose_login_to_server\n  auth:\n    spec:\n      name: unique_name_to_mark_this_auth\n      type: INTERACTIVE_PASSWORD\n      content: 'a placeholder'\n---\nkind: ServerConfig\nspec:\n  name: unique_name_to_mark_this_server\n  host: host_of_server\n  port: port_of_server\n---\nkind: Session\nspec:\n    tag: mnet2\n    name: 腾讯-跳板机\n    plugins:\n        -   kind:   SSH_WETERM\n            args:\n    client:\n      ref:\n        field: name\n        value: unique_name_to_mark_this_client\n    server:\n      ref:\n        field: name\n        value: unique_name_to_mark_this_server\nEOF\n```\n## 附录\n### 数据结构\n```yaml\n---\nkind: AuthMethod\nspec:\n    name: str | nullable\n    type: str\n    content: str\n    expect_for_password: str\n    save_private_key_in_db: bool\n---\nkind: ClientConfig\nspec:\n    user: str\n    name: str | nullable\n    auth:\n        ref:\n            field: id/name\n            value: int/str\n        spec:\n            name: str | nullable\n            type: str\n            content: str\n            expect_for_password: str\n            save_private_key_in_db: bool\n---\nkind: ServerConfig\nspec:\n    name: str\n    host: str\n    port: int\n\n---\nkind: Session\nspec:\n    tag: str\n    name: str\n    plugins:\n        -   kind:   SSH_LOGIN\n            args:\n        -   kind:   EXPECT\n            args:\n                expect: str\n                send:   str\n                raw:\n                -   str\n                -   str\n                -   str\n    client:\n        ref:\n            field: id/name\n            value: int/str\n        spec:\n            user: str\n            name: str | nullable\n            auth:\n                ref:\n                    field: id/name\n                    value: int/str\n                spec:\n                    name: str | nullable\n                    type: str\n                    content: password\n                    expect_for_password: str\n                    save_private_key_in_db: bool\n    server:\n        ref:\n            field: id/name\n            value: int/str\n        spec:\n            name: str\n            host: str\n            port: int\n```\n### 项目建模:\n**AuthMethod**: 连接服务器时, 进行身份验证的方法(PASSWORD、PUBLISH_KEY等)\n**ClientConfig**: 连接服务器时, 使用的身份信息(username), 关联着 AuthMethod\n**ServerConfig**: 连接的服务器信息, 包括(host、port)\n**Session**: ssh会话配置, 描述了使用哪个ClientConfig连接哪个ServerConfig的信息\n项目整体结构:\n```text\n                                                                                             +--------------------+\n                                        +-------------+       +-------------+                |  +--------------+  |\n                                        | config.yaml | --+-- | config.yaml |                |  |              |  |\n                                        +-------------+   |   +-------------+                |  |  AuthMethod  |  |\n                                                          |                                  |  |              |  |\n                                                          |                                  |  +-------+------+  |\n                                                          v                                  |          ^         |\n                                                    +-----+------+                           |          v         |\n                                    cretae/update   |            |                           |  +-------+------+  |\n                                 +----------------->+ YamlParser |                           |  |              |  |\n                                 |                  |            |                           |  | ClientConfig |  |\n                                 |                  +-----+------+                           |  |              |  |\n                                 |                        |                                  |  +-------+------+  |\n                                 |                        |                                  |          |         |\n                                 |                        v                                  |          |         |\n+-----------------+         +----+--------+         +-----+-------+           +----------+   |    +-----+---+     |\n|                 | invoke  |             |  read   |             |           |          |   |    |         |     |\n|  shell-wrapper  +-------->+  Click-cli  +-------->+ sqlalchemy  +---------->+  models  |   |    | Session |     |\n|                 |         |             |         |             |           |          |   |    |         |     |\n+-----+-----------+         +-------------+         +-------------+           +----------+   |    +-----+---+     |\n      ^                                                                                      |          |         |\n      |                                                                                      |          |         |\n      |                                             +-------------+                          |  +-------+------+  |\n      |    eval              +-----------+ generate |             |           bind           |  |              |  |\n      +--------------------+ | expect.sh |  <----+  |   plugins   +<----------------------------+ ServerConfig |  |\n                             +-----------+          |             |                          |  |              |  |\n                                  ..                +-------------+                          |  +--------------+  |\n                                  ..                |             |                          |                    |\n                             +-----------+          | *SSH_LOGIN  |                          +--------------------+\n                             | expect.sh |          |             |\n                             +-----------+          | *SSH_WETERM |\n                                  ..                |             |\n                                  ..                | *EXPECT     |\n                                  ..                |             |\n                                  ..                +-------------+\n                             +-----------+\n                             | expect.sh |\n                             +-----------+\n\n```",
    'author': 'shabbywu',
    'author_email': 'shabbywu@tencent.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'py_modules': modules,
    'install_requires': install_requires,
    'extras_require': extras_require,
    'entry_points': entry_points,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
