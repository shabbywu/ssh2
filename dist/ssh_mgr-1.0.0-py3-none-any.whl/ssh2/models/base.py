# -*- coding: utf-8 -*-
from sqlalchemy.ext.declarative import declarative_base

BaseModel = declarative_base()
